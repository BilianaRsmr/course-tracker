import { Injectable } from '@nestjs/common';

export interface User {
  id: number;
  username: string;
  password: string;
  role: 'user' | 'admin';
}

@Injectable()
export class UsersService {
  private users: User[] = [
    { id: 1, username: 'admin', password: 'admin123', role: 'admin' },
    // alți useri se vor adăuga dinamic prin create()
  ];

  async findOne(username: string): Promise<User | undefined> {
    return this.users.find(user => user.username === username);
  }

  async create(user: Omit<User, 'id' | 'role'>): Promise<User> {
    const newUser: User = {
      ...user,
      id: this.users.length + 1,
      role: 'user',
    };
    this.users.push(newUser);
    return newUser;
  }

  async findAll(): Promise<User[]> {
    return this.users;
  }
}
