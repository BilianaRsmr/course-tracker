import { Module } from '@nestjs/common';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';

import { CoursesModule } from './courses/courses.module';
import { AdminController } from './admin/admin.controller';
import { AdminModule } from './admin/admin.module';
@Module({
  imports: [AuthModule, UsersModule, CoursesModule, AdminModule],
  
})
export class AppModule {}
