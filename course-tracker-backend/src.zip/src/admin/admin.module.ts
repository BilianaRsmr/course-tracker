import { Module } from '@nestjs/common';
import { AdminController } from './admin.controller';
import { UsersModule } from '../users/users.module';
import { CoursesModule } from '../courses/courses.module';

@Module({
  imports: [UsersModule, CoursesModule],
  controllers: [AdminController],
})
export class AdminModule {}
