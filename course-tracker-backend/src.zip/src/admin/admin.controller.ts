import { Controller, Get, UseGuards, Request } from '@nestjs/common';
import { UsersService } from '../users/users.service';
import { CoursesService } from '../courses/courses.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@Controller('admin')
@UseGuards(JwtAuthGuard)
export class AdminController {
  constructor(
    private readonly usersService: UsersService,
    private readonly coursesService: CoursesService
  ) {}

  @Get('users')
  async getAllUsersWithCourses(@Request() req) {
    if (req.user.role !== 'admin') {
      return { message: 'Access denied' };
    }

    const users = await this.usersService.findAll();
    return users.map(user => ({
      id: user.id,
      username: user.username,
      role: user.role,
      courses: this.coursesService.findAllForUser(user.id),
    }));
  }
}
