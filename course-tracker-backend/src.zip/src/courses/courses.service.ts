import { Injectable, NotFoundException } from '@nestjs/common';

export interface Course {
  id: number;
  title: string;
  platform: string;
  duration: number;
  completed: boolean;
  userId: number; // nou
}

@Injectable()
export class CoursesService {
  private courses: Course[] = [
    { id: 1, title: 'NestJS Basics', platform: 'Udemy', duration: 6, completed: false, userId: 1 },
    { id: 2, title: 'React with TypeScript', platform: 'YouTube', duration: 4, completed: true, userId: 2 },
  ];

  findAllForUser(userId: number): Course[] {
    return this.courses.filter(course => course.userId === userId);
  }

  findByPlatformForUser(platform: string, userId: number): Course[] {
    return this.courses.filter(
      course => course.platform === platform && course.userId === userId
    );
  }

  findCompletedForUser(userId: number): Course[] {
    return this.courses.filter(course => course.completed && course.userId === userId);
  }

  create(course: Omit<Course, 'id'>): Course {
    const newCourse: Course = {
      ...course,
      id: this.courses.length + 1,
    };
    this.courses.push(newCourse);
    return newCourse;
  }

  delete(id: number, userId: number): void {
    const index = this.courses.findIndex(c => c.id === id && c.userId === userId);
    if (index === -1) {
      throw new NotFoundException('Course not found');
    }
    this.courses.splice(index, 1);
  }

  update(id: number, updated: Omit<Course, 'id' | 'userId'>, userId: number): Course {
    const index = this.courses.findIndex(c => c.id === id && c.userId === userId);
    if (index === -1) {
      throw new NotFoundException('Course not found');
    }
    const newCourse = { ...updated, id, userId };
    this.courses[index] = newCourse;
    return newCourse;
  }
}