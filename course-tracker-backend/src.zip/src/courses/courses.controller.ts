import { Controller, Get, Post, Delete, Param, Body, Patch, Query, UseGuards, Request } from '@nestjs/common';
import { CoursesService, Course } from './courses.service';
import {JwtAuthGuard } from '../auth/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('courses')
export class CoursesController {
  constructor(private readonly coursesService: CoursesService) {}

  @Get()
  findAll(@Request() req, @Query('platform') platform?: string): Course[] {
    if (platform) {
      return this.coursesService.findByPlatformForUser(platform, req.user.userId);
    }
    return this.coursesService.findAllForUser(req.user.userId);
  }


    @Get('completed')
    getCompleted(@Request() req): Course[] {
        return this.coursesService.findCompletedForUser(req.user.userId);
    }

  @Post()
  create(@Body() course: Omit<Course, 'id' | 'userId'>, @Request() req): Course {
    return this.coursesService.create({ ...course, userId: req.user.userId });
  }

    @Delete(':id')
    delete(@Param('id') id: string, @Request() req): void {
     this.coursesService.delete(Number(id), req.user.userId);
    }

    @Patch(':id')
    update(@Param('id') id: string, @Body() updated, @Request() req): Course {
        return this.coursesService.update(Number(id), updated, req.user.userId);
    }
}
