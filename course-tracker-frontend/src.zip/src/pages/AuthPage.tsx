import React from 'react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './AuthPage.css';

export const AuthPage = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [token, setToken] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async () => {
    const endpoint = isLogin ? 'login' : 'register';
    const res = await fetch(`http://localhost:3000/auth/${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });

    const data = await res.json();

    if (res.ok) {
      if (isLogin) {
        setToken(data.access_token);
        setMessage('Login successful!');
        localStorage.setItem('token', data.access_token);
        navigate('/courses');
      } else {
        setMessage('Account created! You can now log in.');
        setIsLogin(true);
      }
    } else {
      setMessage(data.message || 'Something went wrong');
    }
  };

  return (
    <div className="auth-container">
      <h2>{isLogin ? 'Login to your account' : 'Create a new account'}</h2>

      <input
        placeholder="Username"
        value={username}
        onChange={e => setUsername(e.target.value)}
      />
      <input
        placeholder="Password"
        type="password"
        value={password}
        onChange={e => setPassword(e.target.value)}
      />
      <button onClick={handleSubmit}>
        {isLogin ? 'Login' : 'Register'}
      </button>

      <p className="toggle" onClick={() => {
        setIsLogin(!isLogin);
        setMessage('');
      }}>
        {isLogin ? "Don't have an account? Register here" : "Already have an account? Login here"}
      </p>

      {message && <p className="message">{message}</p>}
      {token && <p className="token">Token: {token}</p>}
    </div>
  );
};
