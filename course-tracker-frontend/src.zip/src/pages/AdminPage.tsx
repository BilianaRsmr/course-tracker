import React from 'react';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface Course {
  id: number;
  title: string;
  platform: string;
  duration: number;
  completed: boolean;
}

interface UserWithCourses {
  id: number;
  username: string;
  role: string;
  courses: Course[];
}

export const AdminPage = () => {
  const [users, setUsers] = useState<UserWithCourses[]>([]);
  const [error, setError] = useState('');
  const token = localStorage.getItem('token');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      const res = await fetch('http://localhost:3000/admin/users', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (res.status === 401) {
        setError('Unauthorized');
        return;
      }

      const data = await res.json();
      if (data.message === 'Access denied') {
        setError('Access denied: Admins only');
      } else {
        setUsers(data);
      }
    };

    if (token) {
      fetchData();
    } else {
      navigate('/');
    }
  }, [token, navigate]);

  if (error) {
    return <p style={{ color: 'red', padding: '20px' }}>{error}</p>;
  }

  return (
    <div style={{ padding: '20px' }}>
      <h1>Admin Dashboard: All Users & Courses</h1>
      {users.map(user => (
        <div key={user.id} style={{ border: '1px solid #ccc', margin: '1rem 0', padding: '1rem' }}>
          <h3>{user.username} ({user.role})</h3>
          {user.courses.length === 0 ? (
            <p>No courses</p>
          ) : (
            <ul>
              {user.courses.map(course => (
                <li key={course.id}>
                  <strong>{course.title}</strong> ({course.platform}) - {course.duration}h -{' '}
                  {course.completed ? '✅' : '❌'}
                </li>
              ))}
            </ul>
          )}
        </div>
      ))}
    </div>
  );
};